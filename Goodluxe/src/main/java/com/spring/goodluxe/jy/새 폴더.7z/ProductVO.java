package com.spring.goodluxe.jy;

public class ProductVO {
	private String entity_number;
	private String pd_name;
	private String brand_number;
	private String category;
	private String quality_grade;
	private int sale_price;
	private String appraise_exist;
	private String pd_component;
	private String member_id;
}
